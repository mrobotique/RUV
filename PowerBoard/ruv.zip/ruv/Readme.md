*Adafruit_MCP23017
https://github.com/adafruit/Adafruit-MCP23017-Arduino-Library
*** Pin Addressing

When using single pin operations such as pinMode(pinId, dir) or digitalRead(pinId) or digitalWrite(pinId, val) then the pins are addressed using the ID's below. For example, for set the mode of GPB0 then use pinMode(8, ...).
Physial Pin # 	Pin Name 	Pin ID
21 	GPA0 	0
22 	GPA1 	1
23 	GPA2 	2
24 	GPA3 	3
25 	GPA4 	4
26 	GPA5 	5
27 	GPA6 	6
28 	GPA7 	7
1 	GPB0 	8
2 	GPB1 	9
3 	GPB2 	10
4 	GPB3 	11
5 	GPB4 	12
6 	GPB5 	13
7 	GPB6 	14
8 	GPB7 	15

*FastLED Library
https://github.com/FastLED/FastLED
**FastLED color reference: http://fastled.io/docs/3.1/struct_c_r_g_b.html

requiere
https://github.com/cosmikwolf/Bounce2mcp.git

requiere ArduinoJson v>=6

